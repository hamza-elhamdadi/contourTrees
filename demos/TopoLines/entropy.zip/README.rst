.. -*- mode: rst -*-

EntroPy is now `DEPRECATED <https://github.com/raphaelvallat/entropy/issues/15>`_. Please use the `AntroPy package <https://github.com/raphaelvallat/antropy>`_ instead!